#include "menuInGame.h"
#include "fonction.h"
#include "menu.h"
#include <unistd.h>
#include <time.h>


void nouvellePartie() {
    int verif;
    int seed;
       do{
        printf("\033c");
        printf("Donner une seed");
        verif=scanf("%d", &seed);
        vide_buffer();
    } while (verif != 1 || seed < 0);

    srand(seed);
    int time_limit = 6 * 60;  // Time limit in seconds (6 minutes)
    time_t start_time = time(NULL);

    printf("\033c");
    int NumberOfRoom = GenerateNumberOfRoom();
    printf("Nombre de salle dans la partie : %d\n", NumberOfRoom);
    World *world = CreateWorld(NumberOfRoom);
    world->Seed=seed;
    Room *room = CreateFirstRoom(world);
    world->rooms[0] = room;

    Player *player = BuildPlayer();
    player->room = world->rooms[0];
    int x = 0, y = 0;
    GetMiddle(&x, &y, world->size);
    player->Position.x = x;
    player->Position.y = y;

    while (player->Hp > 0) {
        // Check elapsed time
        time_t current_time = time(NULL);
        double elapsed_time = difftime(current_time, start_time);
        if (elapsed_time >= time_limit) {
            printf("Time's up!\n");
            break;
        }
	Travel(player, world, elapsed_time);
        
        

        if (player->KillCounter > 8) {
            printf("\033c");
            sleep(1);
                printf("╭────────────────────╮\n");
                printf("│                            │\n");
                printf("│  Bravo, vous avez battu    │\n");
                printf("│       les bugs !           │\n");
                printf("│                            │\n");
                printf("╰────────────────────╯\n");
            sleep(1);
            exit(0);
        }
    }

    if (player->Hp <= 0 || difftime(time(NULL), start_time) >= time_limit) {
        player->Vie -= 1;
        sleep(2);
        printf("Vous êtes mort il vous reste %d chance de gagner\n", player->Vie);
        sleep(2);
        player->Hp = 100;
        player->DeathCounter = 1;
        player->Atk = 10;
        player->Def = 5;
        for (int i = 0; i < 4; i++) {
            player->Inventory[i] = NULL;
        }
        start_time = time(NULL);
        printf("\033c");
        player->Position.x = x;
        player->Position.y = y;

        while (player->Hp > 0) {
	    // Check elapsed time
            time_t current_time = time(NULL);
            double elapsed_time = difftime(current_time, start_time);
            if (elapsed_time >= time_limit) {
                printf("Time's up!\n");
                break;
            }            
	    Travel(player, world, elapsed_time);
            
            

            if (player->KillCounter > 8) {
                printf("\033c");
                sleep(1);
                    printf("╭────────────────────╮\n");
                    printf("│                            │\n");
                    printf("│  Bravo, vous avez battu    │\n");
                    printf("│       les bugs !           │\n");
                    printf("│                            │\n");
                    printf("╰────────────────────╯\n");
                sleep(1);
                exit(0);
            }
        }
    }

    if (player->Hp <= 0 || difftime(time(NULL), start_time) >= time_limit) {
        player->Vie -= 1;
        printf("\033c");
        printf("╭──────────────────────────────╮\n");
        printf("│                                         │\n");
        printf("│  C'est fini les bugs vous ont vaincu    │\n");
        printf("│       Merci d'avoir joué                │\n");
        printf("│                                         │\n");
        printf("╰──────────────────────────────╯\n");
    }
}
void chargerPartie(){
    FILE *file = fopen("savegame.bin", "rb");
    if (file == NULL) {
        perror("Erreur lors de l'ouverture du fichier");
        exit(1);
    }

    GameState loadedGameState;
    size_t read = fread(&loadedGameState, sizeof(GameState), 1, file);
    if (read != 1) {
        perror("Erreur lors de la lecture du fichier");
    }
    fclose(file);

    // Utilisez les données chargées
    printf("Position du joueur: (%d, %d)\n",loadedGameState.player.Position.x, loadedGameState.player.Position.y);
    printf("Adresses player : %p / world : %p\n", &loadedGameState.player, &(loadedGameState.world));
    while(1)    Travel(&(loadedGameState.player),&(loadedGameState.world),1);
}

void menu(){
    int choice;
    int verif;

    do{
	printf("\033c");
    
	printf("\033[33m┌"
	"─────────────────────────"
	"┐\033[0m"
	"\n");
	printf("\033[33m│  Menu                   │\033[0m\n"
	"\033[33m│\033[0m  Nouvelle partie : 1    \033[33m│\033[0m\n"
	"\033[33m│\033[0m  Charger une partie : 2 \033[33m│\033[0m\n"
	"\033[33m│\033[0m  Quitter : 0            \033[33m│\033[0m\n");
	printf("\033[33m└"
	"─────────────────────────"
	"┘\033[0m"
	"\n\n");
	
	verif=scanf("%d", &choice);
        vide_buffer();

    } while (choice!=1 && choice!=0 && choice!=2 && verif !=-1);
    switch (choice) {
        case 1:
            nouvellePartie();
            break;
        case 2:
            printf("Pas fini\n");
            break;
        default:
            exit(0);
    }
}