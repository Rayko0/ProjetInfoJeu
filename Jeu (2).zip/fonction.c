#include "menuInGame.h"
#include "fonction.h"
#include <unistd.h>
#include <math.h>
const int MovX[4] = {0,0,-1,1};
const int MovY[4] = {-1,1,0,0};
const char* VIDE = " ";

//graphiques
char* Doors[4] = {"╠", "╣" , "╦", "╩"};
char* LinkSkin[4] = {"╌", "╌" , "╎", "╎"};
char* Skins[6] = {"🧔", "🤖", "😼" ,"👶", "🤡", "😈"};
char* Monsters[6] = {"▓", "👻", "👽", "👾", "🧞" ,"🧟"};
char* Items[3] = {"🗡","🛡","♡"};//0 = Epee, 1 = Bouclier, 2 = Coeur
char* ItemNames[3] = {"l'épée","le bouclier","te soigner"};//0 = Epee, 1 = Bouclier, 2 = Coeur
char Move[4] = {'q', 'd', 'z', 's'};

int max(int a, int b){return (a>b)?a:b;}
int min(int a, int b){return (a<b)?a:b;}

void convert_seconds_to_minutes(double total_seconds, int *minutes, int *seconds) {
    int total_second = (int)total_seconds;
    *minutes = total_second / 60;
    *seconds = total_second % 60;
}

Mob* BuildMob(){
    Mob* mob = malloc(sizeof(Mob));
    mob->Hp=20;
    mob->Atk=12;
    mob->Esq=3;
    mob->Def=8;
    mob->skin= Monsters[0];
    mob->exist = 1;
    return mob;
}

Item* BuildItem() {
    Item* item = malloc(sizeof(Item));
    int itemnum = rand() % 3;
    item->type = itemnum;
    item->skin = Items[itemnum];
    item->position.x = 0;
    item->position.y = 0;
    item->exist = 1;
    return item;
}

void PrintMessage(char* message){
    // Pour afficher les messages dans un box
    printf("╭"
    "──────────────────────────────────────────────────────────────────────────────────────────"
    "╮"
    "\n");
    printf("                   %s                    \n", message);
    printf("╰"
    "──────────────────────────────────────────────────────────────────────────────────────────"
    "╯"
    "\n");
}

World* CreateWorld(int NumberOfRoom){
    World* world = malloc(sizeof(World));
    //définir les limites de la carte
    world->size.x = MAX_WORLD_SIZE, world->size.y = MAX_WORLD_SIZE;
    //définir le tableau des salles dans le monde
    world->rooms = malloc(sizeof(Room)*NumberOfRoom);

    //define the map array
    world->map = malloc(sizeof(char**) * world->size.x);
    for(int i= 0; i < world->size.x; i++) {
        world->map[i] = malloc(sizeof(char*)*world->size.y);
        for(int j = 0; j < world->size.y; j++) world->map[i][j] = " ";
    }
    
    //définir le nombre maximum de portes
    world->NbMax = NumberOfRoom-1;
    world->NbDoors = 0; 
    world->NbRooms = 0;



    return world;
}

void AddRoomToWorld(World* world, Room* room){
    //fonction pour mettre a jour le tableau de la map avec la nouvelle salle
    for(int i = 0; i < room->size.x; i++){
        for(int j = 0; j < room->size.y; j++){	
		    world->map[room->position.x+i][room->position.y+j] = room->Tab2D[i][j];
        }
    }
}

Player* BuildPlayer(){
    Player* P1 = malloc(sizeof(Player));
    do {
        printf("╭"
        "────────────────────────"
        "╮"
        "\n");
        printf("│  Donnez votre pseudo : │\n");
        printf("╰"
        "────────────────────────"
        "╯"
        "\n");
        scanf("%s", P1->Name);
        size_t len = strlen(P1->Name);
        if (len > 0 && P1->Name[len - 1] == '\n') {
            P1->Name[strlen(P1->Name) - 1] = '\0';
        }
        // Vérifier la longueur du pseudo
        if (len > MAX_NAME_LENGTH) {
	    printf("\033[31m╭"
            "────────────────────────────────────────────────────────────────────"
            "╮"
            "\033[0m\n");
            printf("\033[31m│\033[0m  Le pseudo ne peut pas dépasser %d caractères. Veuillez réessayer. \033[31m│\033[0m\n", MAX_NAME_LENGTH);

            printf("\033[31m╰"
            "────────────────────────────────────────────────────────────────────"
            "╯"
            "\033[0m\n");
        }
    } while (strlen(P1->Name) > MAX_NAME_LENGTH);
    P1->Hp = 100;
    P1->Atk = 10;
    P1->Esq = 10;
    P1->Def = 5;
    P1->Exp=0;
    P1->Position.x=0;
    P1->Position.y=0;
    P1->skin= Skins[0];
    for (int i = 0; i < 4; i++) P1->Inventory[i] = NULL;
    P1->Vie=2;
    P1->KillCounter=0;
    P1->DeathCounter=0;
    return P1;
}

int GenerateNumberOfRoom(){ 
    // Générer un nombre aléatoire de pièces entre 10 et MAXROOM dans un pointeur vers un entier.
    int a;
    a = rand() % 11 + (MAXROOM-10);
    return a;
}

// Fonction pour générer un nombre aléatoire dans une plage
float randomRange(float min, float max) {
    return min + (rand() / (RAND_MAX / (max - min)));
}

// Fonction de combat
void combat(Player *player, Mob *mob, World * world) {

    // Boucle de combat jusqu'à ce que l'un des personnages n'ait plus de points de vie
    while (player->Hp > 0 && mob->Hp > 0) {
        // Le monstre attaque le joueur
        float monsterAttack = randomRange(mob->Atk * 0.8, mob->Atk * 1.2); // Dégâts aléatoires
        float damageToPlayer = max(0, monsterAttack - randomRange(player->Def*0.3, player->Def)); // Défense du joueur prise en compte
        player->Hp -= damageToPlayer;
        if(player->Hp<0) player->Hp=0;
        printf("Le monstre attaque le joueur et lui inflige %.2f points de dégâts. Points de vie restants du joueur : %.2f\n", damageToPlayer, player->Hp);
        sleep(1);
        // Le joueur attaque le monstre
        float playerAttack = randomRange(player->Atk * 0.8, player->Atk * 1.2); // Dégâts aléatoires
        float damageToMonster = max(0, playerAttack - randomRange(mob->Def*0.3, mob->Def)); // Défense du monstre prise en compte
        mob->Hp -= damageToMonster;
        if(mob->Hp<0) mob->Hp=0;
	    printf("Le joueur attaque le monstre et lui inflige %.2f points de dégâts. Points de vie restants du monstre : %.2f\n", damageToMonster, mob->Hp);
    	sleep(1);  
    }  
        // Affichage du résultat du combat
    if (player->Hp <= 0) {
        sleep(1);
	    printf("%s a été vaincu par le bug !\n", player->Name);
        //Donc faut regénérer une map etc
    } 
    else {
        sleep(1);
        printf("%s a vaincu le bug !\n", player->Name);
        player->room->RoomMob->exist=0;
        player->room->Tab2D[player->room->RoomMob->Position.x][player->room->RoomMob->Position.y]=" ";
        player->KillCounter++;
        sleep(1);
        printf("%s a %d Kill\n", player->Name, player->KillCounter);
        AddRoomToWorld(world, player->room);
        player->Exp+=rand()%10+1;
    }
    sleep(1);
}

bool isSpaceFree(World* world, Coordinates pos, int k) {
    //Fonction pour vérifier si l'on peut placer une salle ou non
    if (pos.x - 10 < 0 || pos.x + 10 >= world->size.x || pos.y - 10 < 0 || pos.y + 10 >= world->size.y) return false;
    for (int i = -11 * (k%4 != 3) + 1; i < 11 * (k%4 != 2); i++) {
        for (int j = -11 * (k%4 != 1) + 1; j < 11 * (k%4 != 0); j++) {
            if (world->map[pos.x + i][pos.y + j] != " ") {
                return false; // Espace non libre
            }
        }
    }
    return true; // Espace libre
}

Room* CreateRoom(World* world) {
    int l, L;
    Room* r = malloc(sizeof(Room));

    r->RoomIndex = world->NbRooms;
    L = ((rand() % 4)*2) + 5; // Générer une longueur aléatoire entre 3 et 11 et impaire
    l = ((rand() % 4)*2) + 5; // Générer une largeur aléatoire entre 3 et 11 et impaire

    r->unlocked = false;

    // Ajuster les dimensions si nécessaire pour éviter les salles de type couloir
    if (l - L > 3){
        L+=rand() % 3 + 2;
    }
    if (L - l > 3){
        l+=rand() % 3 + 2;
    }

    r->size.x = l; // Stocker les dimensions
    r->size.y = L;

    // Allouer de la mémoire pour le tableau 2D
    r->Tab2D = malloc(l * sizeof(char**));
    for (int i = 0; i < l; i++) {
        r->Tab2D[i] = malloc(L * sizeof(char*));
        for (int j = 0; j < L; j++) r->Tab2D[i][j] = ".";
    }
    world->NbRooms++;

    return r;
}

void AddItemsToRoom(World* world, Room *r){
   //Fonction pour créer et ajouter des items a une salle 
   Coordinates p;
   int doorIndex;
   Mob* mob = BuildMob();
   do {
        // Générer des coordonnées aléatoires à l'intérieur de la salle
        p.x = rand() % (r->size.x - 3) + 2; // Évitez les bords
        p.y = rand() % (r->size.y - 3) + 2;

        // Vérifier si la position est devant une porte
        doorIndex = -1;
        for (int i = 0; i < 4; i++) {
            if (p.x == r->TabDoor[i].position.x && p.y == r->TabDoor[i].position.y) {
                doorIndex = i;
 		        break; // La position est devant une porte, réessayer
            }
        }
    } while (doorIndex != -1); // Réessayer jusqu'à ce que la position ne soit pas devant une porte 

    mob->Position.x = p.x;
    mob->Position.y = p.y;

    r->Tab2D[p.x][p.y]= mob->skin;
    r->RoomMob = mob;
    
    Item* item = BuildItem();
    Coordinates p2;
    int doorIndex2;
    do {
        // Générer des coordonnées aléatoires à l'intérieur de la salle
        p2.x = rand() % (r->size.x - 3) + 2; // Évitez les bords
        p2.y = rand() % (r->size.y - 3) + 2;

        // Vérifier si la position est devant une porte
        doorIndex2 = -1;
        for (int i = 0; i < 4; i++) {
            if (p2.x == r->TabDoor[i].position.x && p2.y == r->TabDoor[i].position.y) {
                doorIndex2 = i;
 		        break; // La position est devant une porte, réessayer
            }
        }
    } while (doorIndex2 != -1 || p2.x==p.x || p2.y==p.y ); // Réessayer jusqu'à ce que la position ne soit pas devant une porte 
    
    item->position.y=p2.y;
    item->position.x=p2.x;
    r->Tab2D[p2.x][p2.y]=item->skin;
    r->RoomItem = item;
}

void AddDoorToRoom(World* world, Room* r, int ConnectDoor){
    // Porte d'indice 0 -> porte Ouest
    // Porte d'indice 1 -> porte Est
    // Porte d'indice 2 -> porte Nord
    // Porte d'indice 3 -> porte Sud
    int ObDoor = rand() % 3;

    for (int k = 0; k < 4; ++k)
    {
        if(k == ConnectDoor) {
            r->Tab2D[r->TabDoor[k].position.x][r->TabDoor[k].position.y] = Doors[k];
            continue;
        }
        if((rand() % 5 <= 1 && ObDoor) || world->NbDoors >= world->NbMax)  r->TabDoor[k].position.x = r->TabDoor[k].position.y = -1;
        else {
            if(k>=2){
                r->TabDoor[k].position.x = (k%2) * (r->size.x - 1);
                r->TabDoor[k].position.y = rand() % (r->size.y - 2) + 1;
            } else {
                r->TabDoor[k].position.x = rand() % (r->size.x - 2) + 1;
                r->TabDoor[k].position.y = k * (r->size.y - 1);
            }
            Coordinates pos;
            pos.x =  r->TabDoor[k].position.x + r->position.x, pos.y =  r->TabDoor[k].position.y + r->position.y;
            if(!isSpaceFree(world, pos, k)) r->TabDoor[k].position.x = r->TabDoor[k].position.y = -1;
            else world->NbDoors++;
        }
        ObDoor--;

        if(r->TabDoor[k].position.x == -1){
            r->TabDoor[k].RoomIndex = r->RoomIndex;
            r->TabConnectedDoor[k]=NULL;
            continue;
        }
        
        r->Tab2D[r->TabDoor[k].position.x][r->TabDoor[k].position.y] = Doors[k];
        r->TabDoor[k].RoomIndex = r->RoomIndex;

        // creation de la chambre suivante
        Room* NextRoom = CreateRoom(world);

        // Mettre à jour le tableau World avec un pointeur vers la nouvelle salle
        world->rooms[world->NbRooms-1] = NextRoom;

        // Créer la porte de la nouvelle salle où le joueur sortira
        // et établir une liaison entre les deux portes
        // l'est et l'ouest se connectent et le nord avec le sud
        // Donc 0 <-> 1 et 2 <-> 3
        // Donc il suffit de changer la premiére bit pour trouver l'autre porte : on peut utiliser l'operation XOR.
        int NextDoorIndex = k ^ 1;

        if(NextDoorIndex >= 2){
            NextRoom->TabDoor[NextDoorIndex].position.x = (NextDoorIndex%2) * (NextRoom->size.x - 1);
            NextRoom->TabDoor[NextDoorIndex].position.y = rand() % (NextRoom->size.y - 2) + 1;
        } else {
            NextRoom->TabDoor[NextDoorIndex].position.x = rand() % (NextRoom->size.x - 2) + 1;
            NextRoom->TabDoor[NextDoorIndex].position.y = NextDoorIndex * (NextRoom->size.y - 1);
        }
               
        NextRoom->TabDoor[NextDoorIndex].RoomIndex = NextRoom->RoomIndex; 
        
        r->TabConnectedDoor[k] = &(NextRoom->TabDoor[NextDoorIndex]);
        NextRoom->TabConnectedDoor[NextDoorIndex] = &(r->TabDoor[k]);

        
        NextRoom->position.x = r->position.x + r->TabDoor[k].position.x + MovX[k]*2 - NextRoom->TabDoor[NextDoorIndex].position.x;
        NextRoom->position.y = r->position.y + r->TabDoor[k].position.y + MovY[k]*2 - NextRoom->TabDoor[NextDoorIndex].position.y;
        
        AddRoomToWorld(world,NextRoom);

    }
}

void ExploreRoom(World* world, Room* r, int ConnectDoor){
    int l = r->size.x, L = r->size.y;
    for(int i =0; i < l; i++){
        for (int j = 0; j < L; j++) {
             if (r->Tab2D[i][j] != ".") continue;
            
            // Remplir le tableau 2D avec les caractères
            if(i == 0 && j == 0) r->Tab2D[i][j] = "╔";
            else if(i == 0 && j == L-1) r->Tab2D[i][j] = "╗";
            else if(i == l-1 && j == L-1) r->Tab2D[i][j] = "╝";
            else if(i == l-1 && j == 0) r->Tab2D[i][j] = "╚";
            else if (i == 0 || i == l - 1) r->Tab2D[i][j] = "═";
            else if (j == 0 || j == L - 1) r->Tab2D[i][j] = "║";
            else r->Tab2D[i][j] = " ";
        }

    }

    r->unlocked = true;

    AddDoorToRoom(world, r, ConnectDoor);
    AddItemsToRoom(world, r);

    
    //copy the room in the map
    AddRoomToWorld(world, r);
}

Room* CreateFirstRoom(World* world){
    Room* r = CreateRoom(world);
    int x = 0, y =0;
    //trouver les coordonnées du joueur (les définir au milieu de la carte)
    GetMiddle(&x,&y,world->size);

    //définir la position de la pièce dans la carte 
    r->position.x = x-r->size.x/2;
    r->position.y = y-r->size.y/2;

    ExploreRoom(world, r, -1);
    
    return r;
}

void PrintfRoom(Player * P1, World* world){
    printf("\033c");
    printf("Coo du joueur : %d x , %d y\n",P1->Position.x,P1->Position.y);
    printf("Joueur est dans la salle %d\n",P1->room->RoomIndex);
    for (int i = -CameraRangeX; i <= CameraRangeX; i++) {
        for (int j = -CameraRangeY; j <= CameraRangeY; j++){
            if(P1->Position.x + i < 0 || P1->Position.x + j < 0 || P1->Position.x + i >= world->size.x || P1->Position.x + j >= world->size.y) printf(" ");
            if(!i && !j) printf("%s", P1->skin);
            else {
                if(world->map[P1->Position.x + i][P1->Position.y + j]  == ".") { printf(" ");  continue; }
                if(!j &&
                 (world->map[P1->Position.x + i][P1->Position.y + j] == "╦" || world->map[P1->Position.x + i][P1->Position.y + j] == "╩" || world->map[P1->Position.x + i][P1->Position.y + j] == "═")) printf("═");
                else if(!j) printf(" ");
                printf("%s",world->map[P1->Position.x + i][P1->Position.y + j]);
            }
        }
        printf("\n");
    }    
}

void GetMiddle(int *x,int *y, Coordinates Size){

    *x=Size.x/2;
    *y=Size.y/2;

}

int findDoor(Player *P1) {
    // Si la position du joueur ne correspond à une porte, retourne l'indice de celle ci
    for (int i = 0; i < 4; i++) 
        if (P1->Position.x == P1->room->TabDoor[i].position.x + P1->room->position.x 
        && P1->Position.y == P1->room->TabDoor[i].position.y + P1->room->position.y) 
            return i;
        
    // Si la position du joueur ne correspond à aucune porte, retourne -1
    return -1;
}

void doorInteraction(Player* P1, World* world, int dir){
    int choice = -1;
    PrintMessage("Voulez-vous aller dans la prochaine salle ? 1 oui 0 non");
    scanf("%d", &choice);
    if(choice == 1){
        P1->Position.x += MovX[dir]*2;
        P1->Position.y += MovY[dir]*2;

        world->map[P1->Position.x][P1->Position.y] = LinkSkin[dir];
        
        P1->Position.x += MovX[dir];
        P1->Position.y += MovY[dir];

        P1->room = world->rooms[P1->room->TabConnectedDoor[dir]->RoomIndex];


        int NextDoorIndex = dir ^ 1;

        ExploreRoom(world, P1->room, NextDoorIndex);

        P1->room->unlocked = true;
    }
}

void addToInventory(Player *P1, Room * room,World * world){
    if(P1->room->RoomItem->type == 2){
       if(P1->Hp==100){
            printf("Vous avez le max d'Hp\n");
            sleep(1);
            P1->room->Tab2D[P1->room->RoomItem->position.x][P1->room->RoomItem->position.y]="♡";
            P1->room->RoomItem->exist=1;
            AddRoomToWorld(world, P1->room);
        } else P1->Hp = min(100, P1->Hp + 10);               
    }
    else{
        for(int i=0; i<4; i++){
            if(P1->Inventory[i] == NULL){
                P1->Inventory[i] = room->RoomItem;
                printf("L'objet c'est %s\n" ,P1->Inventory[i]->skin);
                if(P1->Inventory[i]->type == 0) P1->Atk+=10;
                else if(P1->Inventory[i]->type == 1) P1->Def+=5;
                break;
            }
        }
        if(room->RoomItem->exist!=0) printf("Inventaire plein !\n");
   }
   
}

void Travel(Player* P1, World* world, double elapsed_time){
    char input;
    int seed_length = (int)log10(world->Seed) + 1; // Calcul de la longueur de la seed
    int additional_spaces_seed = 10 - seed_length; // Calcul du nombre d'espaces supplémentaires pour aligner le texte

 int verif;    
    do {
        PrintfRoom(P1, world);

        // Calcul de la longueur de la vie, de l'attaque et de l'expérience
        // Simplified by directly formatting in printf statements
        int min,sec;
	convert_seconds_to_minutes(elapsed_time, &min,&sec);
	printf("Temps écoulé %d min %d sec\n",min, sec);
        printf("\033[35m○"
               "◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈"
               "○\033[0m   \033[33m┌─────────────────────┐\033[0m\n");
        printf("     \033[35m\033[100mSTATISTIQUES\033[0m                \033[33m│  \033[107mQuelle direction?\033[0m  \033[33m│\033[0m\n"
               "     \033[37mPartie de  : %s \033[0m\033[33m\n", P1->Name);
        printf("     Seed de la partie : %u %*s\033[0m", world->Seed, additional_spaces_seed, " ");
        printf("⭡ : z              \033[33m \033[0m\n");
	if (P1->Hp < 100){
		printf("     \033[32mVie : %.2f\033[0m                 \033[33m \033[0m  ⭠ : q              \033[33m \033[0m\n",
               P1->Hp);
	}
	else {
		printf("     \033[32mVie : %.2f\033[0m                \033[33m \033[0m  ⭠ : q              \033[33m \033[0m\n",
               P1->Hp);
	}
        printf("     \033[91mAttaque : %.2f\033[0m             \033[33m \033[0m  ⭣ : s              \033[33m \033[0m\n",
               P1->Atk);
	if (P1->Exp>=10){
		printf("     \033[36mExpérience : %.2f\033[0m          \033[33m│\033[0m  ⭢ : d   \033[43mMenu : 0\033[0m   \033[33m│\033[0m\n", P1->Exp);
	}
	else {
		printf("     \033[36mExpérience : %.2f\033[0m           \033[33m│\033[0m  ⭢ : d   \033[43mMenu : 0\033[0m   \033[33m│\033[0m\n", P1->Exp);
	
	}
	if (P1->Def>=10){
		printf("     \033[96mDéfense : %.2f\033[0m             \033[33m└─────────────────────┘\033[0m\n", P1->Def);
	}
	else {
		printf("     \033[96mDéfense : %.2f\033[0m              \033[33m└─────────────────────┘\033[0m\n", P1->Def);
	
	}
	printf("     \033[31mNombre de kills : %d\033[0m\n", P1->KillCounter);
	printf("     \033[41m\033[30mNombre de morts : %d\033[0m\n", P1->DeathCounter);
        printf("\033[35m○"
               "◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈◈"
               "○\033[0m"
               "\n\n");
        printf("\033[36m◑"
               "◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡"
               "◐\033[0m"
               "\n");        
	// Afficher l'inventaire
        printf("     \033[36m\033[103mINVENTAIRE\033[0m\n\n");
        for (int i = 0; i < 4; i++) {
            if(P1->Inventory[i] != NULL) printf("     \033[33mEmplacement %d: %s\033[0m\n", i + 1, P1->Inventory[i]->skin);
            else printf("     \033[33mEmplacement %d : Vide\033[0m\n",i+1);
        }

        printf("\033[36m◑"
           "◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡◠◡"
           "◐\033[0m"
           "\n\n");
        verif=scanf("%c", &input);
        vide_buffer();
	} while (input!='z' && input!='q' && input!='s' && input!='d' && input!='0' && verif !=-1);

    int choice = 0;
    while(Move[choice] != input && choice < 4){
	 choice++;
    }
    if(choice == 4) {
        GameState GameState;
	    GameState.world = *world;
	    GameState.player = *P1;
	    menuInGame(GameState);
    }
    else{
    if (world->map[P1->Position.x  + MovX[choice]][P1->Position.y  + MovY[choice]] == Doors[choice]){
        if(!world->rooms[P1->room->TabConnectedDoor[choice]->RoomIndex]->unlocked) {
            doorInteraction(P1, world,choice);
        }
        else{
            P1->Position.x += 3*MovX[choice];
            P1->Position.y += 3*MovY[choice];
            P1->room = world->rooms[P1->room->TabConnectedDoor[choice]->RoomIndex];
        }
    }
    if (world->map[P1->Position.x + MovX[choice]][P1->Position.y + MovY[choice]] == " "){
        P1->Position.x += MovX[choice];
        P1->Position.y += MovY[choice];
    }
    else if (world->map[P1->Position.x + MovX[choice]][P1->Position.y + MovY[choice]] == "▓"){
        int choix;
	    printf("ça fight ce bug ou quoi ?\n");
    	printf("Oui : 1 / J'ai peur : 0\n");
	    scanf("%d", &choix);
        switch(choix){
            case 1:
                combat(P1,P1->room->RoomMob, world);
                break;
            default:
                break;
        }
    }
    else if (world->map[P1->Position.x + MovX[choice]][P1->Position.y + MovY[choice]] == Items[P1->room->RoomItem->type]){
        char choix;
        if(P1->room->RoomItem->type == 2) printf("Veux tu te soigner ?\n");
        else if(P1->room->RoomItem->type == 1) printf("Veux tu ajouter un bouclier à ton inventaire ?(+5 de défense)\n");
        else if(P1->room->RoomItem->type == 0) printf("Veux tu ajouter une épée à ton inventaire ? (+10 d'Attaque)\n");
	printf("Oui : 1 / Non : 0\n");
        scanf("%c", &choix);
        if(choix == '1'){
            P1->room->Tab2D[P1->room->RoomItem->position.x][P1->room->RoomItem->position.y]=" ";
            P1->room->RoomItem->exist=0;
            AddRoomToWorld(world, P1->room);
            addToInventory(P1, P1->room, world);
        }
    }
}
}
