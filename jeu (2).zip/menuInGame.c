#include <stdio.h>
#include <stdlib.h>
#include "menuInGame.h"
void clearScreen() {
    // Cette fonction dépend du système d'exploitation
    // Sur Windows, utilisez "cls"
    // Sur Unix/Linux/Mac, utilisez "clear"
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void saveGame(GameState GameState){
	FILE *file;
file = fopen("savegame.bin", "wb");
if (file == NULL) {
    perror("Erreur lors de l'ouverture du fichier");
    exit(1);
}
size_t written = fwrite(&GameState, sizeof(GameState), 1, file);
if (written != 1) {
    perror("Erreur lors de l'écriture dans le fichier");
}
fclose(file);
	exit(0);
}

void leaveGame(){
	exit(0);
}
void menuInGame(GameState GameState){
    clearScreen();
    printf("=========================================\n");
    printf("|            Menu En jeu                |\n");
    printf("=========================================\n");
    printf("| 1. Sauvegarder                        |\n");
    printf("| 2. Quitter                            |\n");
    printf("=========================================\n");
    printf("Veuillez choisir une option : ");

	int choice;
	scanf("%d", &choice);
	switch (choice) {
		case 1 :
			saveGame(GameState);
			break;
		default :
			exit(0);

	}
}