#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "menuInGame.h"
#include "fonction.h"
#include "menu.h"
#define MAXROOM 20
#define MAX_NAME_LENGTH 5

int main() {
    menu();

    return 0;
}
