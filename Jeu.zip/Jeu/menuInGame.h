#ifndef MENUINGAME_H
#define MENUINGAME_H

#include<stdio.h>
#include<stdlib.h>
void saveGame();
void menuInGame();
#endif