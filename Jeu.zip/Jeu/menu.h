#ifndef MENU_H
#define MENU_H

#include <stdio.h>
#include <stdlib.h>
void nouvellePartie();
void chargerPartie();
void menu();
#endif
